FRENZY_ALLOC_POLICY_DICT = {
    # 0: 'SJF',  # 'short job first', SJF
    # 1: 'SJU',  # SJF with estimator using USER feature
    # 2: 'SJG',  # SJF with estimator using GROUP, USER feature
    # 4: 'SJGG',  # SJF with estimator using GROUP, USER, GPU feature
    8: 'FIFO',  # FIFO, the default
}

# FRENZY_SCHED_POLICY
FRENZY_FIRST_FIT = 0
FRENZY_BEST_FIT = 1