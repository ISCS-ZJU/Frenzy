'''
根据模型训练的总浮点数运算和训练配置计算训练时间
'''
import math
import collections
import flops_computation

def get_train_duration(ModelConfig, TrainConfig):
    '''
    ModelConfig: 模型参数配置
    TrainConfig: 训练配置
    '''
    # 模型参数
    mc_layerNum = ModelConfig['layers']                 # number of layers
    mc_hidDim = ModelConfig['hidden_dimension']         # hidden size
    mc_seqLength = ModelConfig['seq_length'] if 'seq_length' in ModelConfig else 512      # sequence length
    mc_vocabSize = ModelConfig['vocab_size'] if 'vocab_size' in ModelConfig else 30522    # vocab size
    mc_decoder = ModelConfig['decoder'] if 'decoder' in ModelConfig else False            # decoder?  # decoder has extra attn to encoder states
    mc_attenHeads =  ModelConfig['atten_heads'] if 'atten_heads' in ModelConfig else None # attention heads
    mc_embedSize = ModelConfig['embed_size'] if 'embed_size' in ModelConfig else None     # embedding size  
    mc_intermediateSize = ModelConfig['intermediate_size'] if 'intermediate_size' in ModelConfig else None # intermediate size, 通常前馈层实现 h→4h
    mc_headSize = ModelConfig['head_size'] if 'head_size' in ModelConfig else None        # head size

    mc_outputFrac = ModelConfig['output_frac'] if 'output_frac' in ModelConfig else 0.15625 # percent of tokens using an output softmax 有多少比例的 tokens 被用来计算输出 softmax
    mc_sparseEmbedLookup = ModelConfig['sparse_embed_lookup'] if 'sparse_embed_lookup' in ModelConfig else False      # sparse embedding lookups

    # 训练配置参数
    tc_gBatchSize = TrainConfig['global_batch_size'] if 'global_batch_size' in TrainConfig else 128   # global batch size
    tc_DP = TrainConfig['DP'] if 'DP' in TrainConfig else 1       # 数据并行数
    tc_TP = TrainConfig['TP'] if 'TP' in TrainConfig else 1       # 张量并行数
    tc_TrainSteps = TrainConfig['train_steps'] if 'train_steps' in TrainConfig else 1   # train steps
    tc_discriminator = TrainConfig['discriminator'] if 'discriminator' in TrainConfig else False
    tc_FLOPS = TrainConfig['FLOPS'] if 'FLOPS' in TrainConfig else 312*(10**12)     # A100 PCIe, FP16 Tensor Core, 312 TFLOPS

    tc_batchSize = math.ceil(tc_gBatchSize/(tc_DP*tc_TP))

    # 创建transformer超参数实例
    transformerHparams = flops_computation.TransformerHparams(h=mc_hidDim, l=mc_layerNum, s=mc_seqLength, v=mc_vocabSize,
                                            e=mc_embedSize, i=mc_intermediateSize, heads=mc_attenHeads,
                                            head_size=mc_headSize, output_frac=mc_outputFrac, 
                                            sparse_embed_lookup=mc_sparseEmbedLookup, decoder=mc_decoder)
    
    # 浮点运算数 FLoating OPerations
    FLOPs = transformerHparams.get_train_flops(batch_size=tc_batchSize, train_steps=tc_TrainSteps, discriminator=tc_discriminator)

    # print('FLOPs: ', FLOPs)

    # 计算时间
    train_time = int(FLOPs / tc_FLOPS + 1)

    return train_time

MODEL_DURATIONs = collections.OrderedDict(
    [
    # # These runtimes were computed with tensorflow FLOPs counting instead of the
    # # script, as the neural architectures are quite different.
    # # 768648884 words in LM1b benchmark, 10 epochs with batch size 20,
    # # seq length 128, 568093262680 FLOPs per example.
    # ("elmo", 2 * 10 * 768648884 * 568093262680 / (20.0 * 128)),
    # # 15064773691518 is FLOPs for forward pass on 32 examples.
    # # Therefore 2 * steps * batch_size * 15064773691518 / 32 is XLNet compute
    # ("xlnet", 2 * 500000 * 8192 * 15064773691518 / 32.0),

    # Runtimes computed with the script
    ("gpt", get_train_duration(dict(hidden_dimension=768, layers=12, vocab_size=40000, output_frac=1.0), dict(global_batch_size=512, DP=2, TP=2, train_steps=960800,))),  
    ("bert_small", get_train_duration(dict(hidden_dimension=256, layers=12, embed_size=128, seq_length=128,), dict(train_steps=1.45e6,))),
    ("bert_base", get_train_duration(dict(hidden_dimension=768, layers=12, ), dict(global_batch_size=256, train_steps=1e6,))),
    ("bert_large", get_train_duration(dict(hidden_dimension=1024, layers=24, ), dict(global_batch_size=256, train_steps=1e6,))),

    # RoBERTa, ALBERT, and T5 have  minor architectural differences from
    # BERT/ELECTRA, but I believe they don't significantly effect the runtime,
    # so we use this script for those models as well.
    ("roberta", get_train_duration(dict(hidden_dimension=1024, layers=24, vocab_size=50265, ), dict(global_batch_size=8000, train_steps=500000,))),
    ("albert", get_train_duration(dict(hidden_dimension=4096, layers=12, vocab_size=30000, embed_size=128, ), dict(global_batch_size=4096, train_steps=1.5e6,))),
    ("t5_11b", get_train_duration(dict(hidden_dimension=1024, layers=24, vocab_size=32000, intermediate_size=65536, atten_heads=128, head_size=128, output_frac=0.0), dict( global_batch_size=2048, train_steps=1e6,)) +  # 1M steps with batch size 2048
               get_train_duration(dict(hidden_dimension=1024, layers=24, vocab_size=32000, intermediate_size=65536, atten_heads=128, head_size=128, output_frac=1.0, decoder=True), dict(global_batch_size=2048, train_steps=1e6,))),
])

def main():
    # ModelConfig与TrainConfig请参考如下设置
    # # gpt
    # modelCfg = dict(
    #     layers = 12,
    #     hidden_dimension = 768,
    #     seq_length = 512,
    #     vocab_size = 40000,
    #     atten_heads = 12,
    #     decoder = False,
    #     embed_size = None,
    #     intermediate_size = None, 
    #     head_size = None,
    #     outputFrac=1.0,
    #     sparse_embed_lookup=False,
    # )
    # trainCfg = dict(
    #     global_batch_size = 512,
    #     DP=2,
    #     TP=2,
    #     train_steps=960800,
    #     FLOPS=312*(10**12),  # A100 PCIe, FP16 Tensor Core, 312 TFLOPS
    #     discriminator=False,
    # )

    for k, v in MODEL_DURATIONs.items():
        print(f'{k}: {v}s = {v/60/60:.2f}h = {v/60/60/24:.2f}d')


if __name__ == "__main__":
    main()
