from MARP import MARP
from duration import get_train_duration