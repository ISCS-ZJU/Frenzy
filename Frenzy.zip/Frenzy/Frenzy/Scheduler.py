'''
从来自MARP提供的多个资源调度中, 根据集群已有资源选择一个最合适的调度策略并分配资源

'''

import copy

FRENZY_FIRST_FIT = 0
FRENZY_BEST_FIT = 1

def allocate_job_to_cluster(rsc_cfgs, cluster, use_bandwidth=False, alloc_policy=8):
    """
    调度器-分配资源

    Args:
        rsc_cfg(list): 可能的资源配置列表, 按所需GPU数从小到大排列, 必须有"gpu_size"和"gpu_num"
        cluster(list): 集群资源列表
          每一项是一个节点的可用资源, 格式为：{"node_id":20, "gpu_type":"A100", "gpu_size":40, "tot_gpu_num":4, "free_gpu_num":2}
            node_id: 节点标识, 必需
            gpu_type: gpu类型, 可选
            gpu_size: gpu大小, 必需
            tot_gpu_num: 节点总gpu数, 必需
            free_gpu_num: 可用gpu数目, 必需
        use_bandwidth(bool): 是否考虑网络带宽, 如果为True, cluster中每个节点字典需要包含"bandwidth"键值对

    Returns:
        -1: 集群无法满足该训练任务, 任务失败
        0:  集群暂时无法满足该训练任务, 挂起任务
        [cfg, node_gpu_used]: 成功完成资源分配, 返回一个列表：
                                                            第一项是对应的资源分配方案
                                                            第二项中的每一项对应cluster中的一个node, 值表示占用了该节点的GPU数
    """
    if use_bandwidth:
        raise NotImplementedError("Scheduling policy with bandwidth is TODO.")
    
    # 分析集群资源
    gpu_eq = {}         # 等于某内存的集群总gpu数, e.g {32:2, 40:3, 80:4}, key表示某个GPU内存
    gpu_ge = {}         # 大于等于某内存的集群总GPU数, e.g {32:9, 40:7, 80:4}
    free_gpu_eq = {}     # 等于某内存的可用gpu数
    free_gpu_ge = {}     # 大于等于某内存的可用gpu数
    for node in cluster:
        gpu_size = node['gpu_size']
        if gpu_size not in gpu_eq:
            gpu_eq[gpu_size] = node['tot_gpu_num']
        else:
            gpu_eq[gpu_size] += node['tot_gpu_num']

        if gpu_size not in free_gpu_eq:
            free_gpu_eq[gpu_size] = node['free_gpu_num']
        else:
            free_gpu_eq[gpu_size] += node['free_gpu_num']

    # 对gpu_eq和free_gpu_eq按照key(GPU大小进行降序排序)
    gpu_eq = dict(sorted(gpu_eq.items(), key=lambda item: item[0], reverse=True))
    free_gpu_eq = dict(sorted(free_gpu_eq.items(), key=lambda item: item[0], reverse=True))

    gpu_size_list = list(gpu_eq.keys()) # 所有可能的gpu size列表, 已经按照size大小降序排序

    # 获得gpu_ge与free_gpu_ge
    for i in range(len(gpu_size_list)):
        gpu_size = gpu_size_list[i]
        if i==0:
            gpu_ge[gpu_size] = gpu_eq[gpu_size]
            free_gpu_ge[gpu_size] = free_gpu_eq[gpu_size]
        else:
            gpu_size_last = gpu_size_list[i-1]
            gpu_ge[gpu_size] = gpu_ge[gpu_size_last] + gpu_eq[gpu_size]
            free_gpu_ge[gpu_size] = free_gpu_ge[gpu_size_last] + free_gpu_eq[gpu_size]

    # 资源调度
    for cfg in rsc_cfgs:
        mem = cfg['mem_per_gpu']
        gpu_num = cfg['gpu_nums']
        size = gpu_ceil(mem, gpu_size_list)
        cfg['gpu_size'] = size  # 更新cfg['gpu_size']

        if size==-1:
            continue
        else:
            if gpu_num <= free_gpu_ge[size]: # 能够分配
                gpu_alloc_list = get_gpu_alloc_list(size, gpu_num, gpu_size_list, free_gpu_eq) # 基于集群可用资源获得合适的资源分配方案
                node_gpu_used = allocate_gpu(gpu_alloc_list, cluster, sche_policy=FRENZY_BEST_FIT)   # 基于资源分配方案进行资源分配, 获得每个节点的资源占用情况
                return [cfg, node_gpu_used]
            # else:
            #     continue

    # 当前可用资源无法满足资源需求, 判断集群所有资源是否可满足训练需要
    return job_can_alloc_to_cluster(rsc_cfgs, gpu_size_list, gpu_ge)

# def can_allo_job_clus(rsc_cfgs, cluster):
#     """
#     判断是否可以根据rsc_cfgs为集群分配资源，其实是allocate_job_to_cluster函数的一部分, 只判断, 不分配

#     Args:
#         rsc_cfg(list): 可能的资源配置列表, 按所需GPU数从小到大排列, 必须有"gpu_size"和"gpu_num"
#         cluster(list): 集群资源列表
#           每一项是一个节点的可用资源, 格式为：{"node_id":20, "gpu_type":"A100", "gpu_size":40, "tot_gpu_num":4, "free_gpu_num":2}
#             node_id: 节点标识, 必需
#             gpu_type: gpu类型, 可选
#             gpu_size: gpu大小, 必需
#             tot_gpu_num: 节点总gpu数, 必需
#             free_gpu_num: 可用gpu数目, 必需

#     Returns:
#         -1: 集群无法满足该训练任务, 任务失败
#         0:  集群暂时无法满足该训练任务, 挂起任务
#         1:  集群能够完成资源分配
#     """
    
#     # 分析集群资源
#     gpu_eq = {}         # 等于某内存的集群总gpu数, e.g {32:2, 40:3, 80:4}, key表示某个GPU内存
#     gpu_ge = {}         # 大于等于某内存的集群总GPU数, e.g {32:9, 40:7, 80:4}
#     free_gpu_eq = {}     # 等于某内存的可用gpu数
#     free_gpu_ge = {}     # 大于等于某内存的可用gpu数
#     for node in cluster:
#         gpu_size = node['gpu_size']
#         if gpu_size not in gpu_eq:
#             gpu_eq[gpu_size] = node['tot_gpu_num']
#         else:
#             gpu_eq[gpu_size] += node['tot_gpu_num']

#         if gpu_size not in free_gpu_eq:
#             free_gpu_eq[gpu_size] = node['free_gpu_num']
#         else:
#             free_gpu_eq[gpu_size] += node['free_gpu_num']

#     # 对gpu_eq和free_gpu_eq按照key(GPU大小进行降序排序)
#     gpu_eq = dict(sorted(gpu_eq.items(), key=lambda item: item[0], reverse=True))
#     free_gpu_eq = dict(sorted(free_gpu_eq.items(), key=lambda item: item[0], reverse=True))

#     gpu_size_list = list(gpu_eq.keys()) # 所有可能的gpu size列表, 已经按照size大小降序排序

#     # 获得gpu_ge与free_gpu_ge
#     for i in range(len(gpu_size_list)):
#         gpu_size = gpu_size_list[i]
#         if i==0:
#             gpu_ge[gpu_size] = gpu_eq[gpu_size]
#             free_gpu_ge[gpu_size] = free_gpu_eq[gpu_size]
#         else:
#             gpu_size_last = gpu_size_list[i-1]
#             gpu_ge[gpu_size] = gpu_ge[gpu_size_last] + gpu_eq[gpu_size]
#             free_gpu_ge[gpu_size] = free_gpu_ge[gpu_size_last] + free_gpu_eq[gpu_size]

#     # 资源调度
#     for cfg in rsc_cfgs:
#         mem = cfg['mem_per_gpu']
#         gpu_num = cfg['gpu_nums']
#         size = gpu_ceil(mem, gpu_size_list)

#         if size==-1:
#             continue
#         else:
#             if gpu_num <= free_gpu_ge[size]: # 能够分配
#                 return 1
#             # else:
#             #     continue

#     # 当前可用资源无法满足资源需求, 判断集群所有资源是否可满足训练需要
#     return job_can_alloc_to_cluster(rsc_cfgs, gpu_size_list, gpu_ge)

def gpu_ceil(mem, gpu_size_lst, util_rate=0.95):
    """
    获取对于所需gpu内存最合适的GPU大小, 如需要一块38GB的GPU, 根据可用GPU列表可知size为40GB的GPU最合适

    Args:
        mem: 所需GPU内存
        gpu_size_lst: 所有可用GPU大小
        util_rate: 给定一个利用率, mem不应超过gpu_size*util_rate
    
    Returns:
        size: 最合适的GPU size
        -1: mem超出最大的GPU size
    """

    gpu_size_list = copy.deepcopy(gpu_size_lst)
    gpu_size_list.sort() # 升序排序

    res = -1

    for size in gpu_size_list: 
        if mem < size * util_rate:
            res = size
            break
    
    return res

def allocate_gpu(gpu_alloc_dict, cluster, sche_policy=FRENZY_FIRST_FIT):
    """
    从集群空闲GPU分配需要的资源

    Args:
        gpu_alloc_dict(dict): 需要分配的资源, key为GPU size, value为需要的GPU数
        cluster(list): 资源集群, node_gpu_used的key对应cluster下标
        sche_policy: 调度策略

    Returns:
        node_gpu_used(list): 一个列表, 每一项对应cluster中的一个node, 值表示占用了该节点的GPU数
    """
    # gpu_alloc_list = copy.deepcopy(gpu_alloc_lst)
    # node_gpu_used = [0] * len(cluster)
    # for index in range(len(cluster)):
    #     node = cluster[index]
    #     gpu_size = node['gpu_size']
    #     if gpu_size in gpu_alloc_list and gpu_alloc_list[gpu_size]>0:
    #         if gpu_alloc_list[gpu_size] > node['free_gpu_num']:    # 该节点GPU不足以满足所需资源
    #             gpu_alloc_list[gpu_size]-=node['free_gpu_num']
    #             node_gpu_used[index] = node['free_gpu_num']
    #             node['free_gpu_num']=0
    #         else:                                                   # 该节点GPU数目足够
    #             node['free_gpu_num']-=gpu_alloc_list[gpu_size]
    #             node_gpu_used[index] = gpu_alloc_list[gpu_size]
    #             gpu_alloc_list[gpu_size]=0
    #     else:
    #         continue
    # return node_gpu_used

    # first fit
    node_gpu_used = []
    if sche_policy==FRENZY_FIRST_FIT:
    # if True:
        for node in cluster:
            gpu_size = node['gpu_size']
            if gpu_size in gpu_alloc_dict and gpu_alloc_dict[gpu_size]>0:
                if gpu_alloc_dict[gpu_size] > node['free_gpu_num']:    # 该节点GPU不足以满足剩余所需资源
                    gpu_alloc_dict[gpu_size]-=node['free_gpu_num']
                    node_gpu_used.append(dict(node_id=node['node_id'], gpu_used=node['free_gpu_num']))
                    node['free_gpu_num']=0
                else:                                                   # 该节点GPU数目足够满足剩余所需资源
                    node['free_gpu_num']-=gpu_alloc_dict[gpu_size]
                    node_gpu_used.append(dict(node_id=node['node_id'], gpu_used=gpu_alloc_dict[gpu_size]))
                    gpu_alloc_dict[gpu_size]=0
            else:
                continue
    # best fit
    # 只需要对gpu_alloc_lst中最大size对应的GPU进行分配即可
    #  如：gpu_alloc_lst = {32:6, 40:2, 64:2} 说明集群中所有的空闲32GB和40GB卡用于该作业，对64GB卡进行best-fit调度
    elif sche_policy==FRENZY_BEST_FIT:
        gpu_alloc_lst = sorted(gpu_alloc_dict.items(), key=lambda d: d[0]) # {40:2, 64:2, 32:6} => [(32,6), (40,2), (64,2)]
        clus = copy.deepcopy(cluster)
        clus.sort(key=lambda x: x['free_gpu_num']) # 根据每个节点剩余GPU数对节点排序
        for node in clus:
            node_gpu_sz = node['gpu_size']
            for idx in range(len(gpu_alloc_lst)-1):
                if node_gpu_sz==gpu_alloc_lst[idx][0]:
                    node_gpu_used.append(dict(node_id=node['node_id'], gpu_used=node['free_gpu_num']))
                    node['free_gpu_num']=0
        
        # 对最大size需求的节点进行best-fit调度
        req_gpu_size = gpu_alloc_lst[-1][0]
        req_gpu_num = gpu_alloc_lst[-1][1]
        while req_gpu_num>0:
            max_node = None
            one_node_enough = False
            for node in clus:
                if node['gpu_size'] != req_gpu_size or node['free_gpu_num']<=0:
                    continue
                max_node = node
                if node['free_gpu_num'] >= req_gpu_num:     # node按剩余gpu数从小到大排列，因此第一个满足的即为最合适的
                    node_gpu_used.append(dict(node_id=node['node_id'], gpu_used=node['free_gpu_num']))
                    req_gpu_num -= node['free_gpu_num']
                    node['free_gpu_num'] = 0
                    one_node_enough = True
                    break
                # else:
                #     continue
            if one_node_enough is False: # 剩余GPU数最大的节点也无法满足要求
                if max_node is not None: # 使用剩余最大节点
                    node_gpu_used.append(dict(node_id=max_node['node_id'], gpu_used=max_node['free_gpu_num']))
                    req_gpu_num-=max_node['free_gpu_num']
                    max_node['free_gpu_num']=0
                else:
                    raise RuntimeError("Fail to allocate resources. Get wrong gpu_alloc_dict.")
    else:
        raise RuntimeError("Incorrect scheduling policy. Please check parameter(sche_policy).")

    return node_gpu_used

def free_gpu(node_gpu_used, cluster):
    """
    释放作业占用的GPU资源返还给集群

    Args:
        node_gpu_used(dict): 集群中GPU占用字典, key为节点号, value为占用的GPU数
        cluster(list): 资源集群, node_gpu_used的key对应cluster下标
    """
    # for index in range(len(node_gpu_used)):
    #     node = cluster[index]
    #     node_gpu_used_num = node_gpu_used[index]
    #     node['free_gpu_num'] = min(node['free_gpu_num'] + node_gpu_used_num,  node['tot_gpu_num'])
    for node in cluster:
        for node_used in node_gpu_used:
            if node['node_id'] == node_used['node_id']:
                node_gpu_used_num = node_used['gpu_used']
                node['free_gpu_num'] = min(node['free_gpu_num'] + node_gpu_used_num,  node['tot_gpu_num'])
    
def get_gpu_alloc_list(gpu_size, gpu_num, gpu_size_lst, free_gpu_eq):
    """
    根据集群可用资源给定合适的资源分配方案
        gpu_size: 需要的gpu大小
        gpu_num: 需要的gpu数目 
        gpu_size_lst(list): 集群所有可能的GPU size
        free_gpu_eq(list)

    Returns
        gpu_alloc_list(list): 合适的gpu列表
    """

    gpu_size_list = sorted(gpu_size_lst) # gpu_size_lst从小到大排序
    gpu_alloc_list = {}
    for sz in gpu_size_list: 
        if sz < gpu_size:
            continue

        if gpu_num<free_gpu_eq[sz]:
            gpu_alloc_list[sz]=gpu_num
            gpu_num=0
        else:
            gpu_alloc_list[sz]=free_gpu_eq[sz]
            gpu_num-=free_gpu_eq[sz]
                    
        if gpu_num==0:
            break
    
    return gpu_alloc_list

def job_can_alloc_to_cluster(rsc_cfgs, gpu_size_lst, gpu_ge):
    """
    判断作业是否可以分配到集群中

    Args:
        rsc_cfgs(list)
        gpu_size_lst(list): 集群所有可能的GPU size
        gpu_ge(list)

    Returns:
        -1: 即使集群所有资源用于该任务也无法满足该任务需求
        0:  集群可能暂时无法满足该训练任务, 但该任务是有可能满足的
    """
    gpu_size_list = sorted(gpu_size_lst)
    for cfg in rsc_cfgs:
        mem = cfg['mem_per_gpu']
        gpu_num = cfg['gpu_nums']
        size = gpu_ceil(mem, gpu_size_list)

        if size>0 and gpu_num<=gpu_ge[size]:
            return 0
            
    return -1   # 无法满足需求



def main():
    rsc_cfg = [
        {'mem_per_gpu': 96, 'tp': 1, 'dp': 1, 'gpu_nums': 1}, # 96>100*0.95
        {'mem_per_gpu': 67, 'tp': 2, 'dp': 2, 'gpu_nums': 6},
        {'mem_per_gpu': 36, 'tp': 2, 'dp': 4, 'gpu_nums': 8},
    ]

    cluster = [
        {"node_id":1, "gpu_size":40, "tot_gpu_num":8, "free_gpu_num":6},
        {"node_id":3, "gpu_size":80, "tot_gpu_num":4, "free_gpu_num":1},
        {"node_id":3, "gpu_size":32, "tot_gpu_num":4, "free_gpu_num":4},
        {"node_id":4, "gpu_size":80, "tot_gpu_num":4, "free_gpu_num":2},
        {"node_id":5, "gpu_size":100, "tot_gpu_num":2, "free_gpu_num":1},
    ]

    res = allocate_job_to_cluster(rsc_cfg, cluster)

    if res==-1:
        print("集群资源无法满足训练需求，训练失败")
    elif res==0:
        print("集群资源目前无法满足训练需求，作业被挂起")
    else:
        node_gpu_used = res[1]
        print('<<< 作业执行中 >>>')
        print('资源占用情况: ', node_gpu_used)
        print('集群资源情况: ', cluster[0])
        for node in cluster[1:]:
            print('              ', node)

        print('<<< 作业执行完毕 >>>')
        free_gpu(node_gpu_used, cluster)
        print('资源释放...')
        print('集群资源情况: ', cluster[0])
        for node in cluster[1:]:
            print('              ', node)



if __name__ == '__main__':
    main()